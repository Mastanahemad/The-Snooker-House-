# The Snooker House – Android app starter

Luxury black / gold / snooker-green React Native + Expo application.

## Included in this project
- Customer and owner views in one Android app (role/view switch for prototype).
- English, Hindi and Marathi UI strings.
- Four configured tables with owner-editable custom hourly rates and status.
- Booking form with customer name, mobile, date, time, duration and price calculation.
- Basic overlapping-booking check within this device's locally saved data.
- 24-hour operating schedule and 24-hour time entry validation.
- Past-date booking prevention.
- Custom rate must be configured per table before accepting a booking.
- Booking history and cancellation in the local prototype.
- Owner dashboard with today's demo revenue, bookings and table status.
- AsyncStorage persistence on the device.
- Supabase PostgreSQL starter schema for the production backend.

## Run on Android
1. Install Node.js LTS and Android Studio (or use Expo Go on an Android phone).
2. Extract this folder.
3. In this folder run:
   ```bash
   npm install
   npx expo start
   ```
4. Scan the QR code using Expo Go, or press `a` to launch an Android emulator.

## Important: prototype vs production
This is a runnable MVP starter, **not a published Play Store app or a production booking/payment service**.
Local bookings are stored only on the device. Two phones will not see each other's bookings until the Supabase backend is connected and the app's data layer is replaced with authenticated API calls. The included SQL is a starting schema, not a fully secured deployment. Add role-aware Row Level Security policies and server-side booking validation before exposing it publicly.

## Before live launch
- Confirm club phone, exact map pin, table labels/types and final custom hourly rate for each of the four tables. Address entered: Sawe Wadi, Latur, Maharashtra. Operating hours: 24 hours.
- Confirm table types (snooker / pool), table labels and hourly rates.
- Create Supabase project; apply `supabase/migrations/001_initial_schema.sql`.
- Add Supabase Auth, role-aware RLS, server-side availability checks and audit logs.
- Integrate a payment provider (e.g. Razorpay) through a secure backend; keep secret keys server-side. Verify payment webhooks before marking bookings paid.
- Add staff roles, admin PIN/OTP, refunds, cancellation policy and backup.
- Add privacy policy, terms, consent and data-retention rules.
- Test daylight/time-zone handling, simultaneous bookings, failed payments and poor connectivity.
- Configure app icon, splash screen, signing key and Play Store listing.

## Suggested production modules
1. Customer: account/OTP, browse availability, booking, payment, QR check-in, membership, tournaments, cafe orders, notifications.
2. Owner: live occupancy, walk-in sessions, timer, extensions, POS, expenses, stock, staff, discounts and reports.
3. Staff: front desk check-in, session timer, billing and cafe order workflow.
4. Backend: Supabase Auth + PostgreSQL + Edge Functions + payment gateway webhooks + push notifications.

## Brand defaults
- Name: The Snooker House
- Website: https://thesnookerhouse.com
- Palette: #0B100D, #151D18, #D7B56D, #245B3C
- Android package: `com.thesnookerhouse.app`


## Confirmed operating settings (2026-11-16)
- Address: Sawe Wadi, Latur, Maharashtra, India
- Operating hours: 24 hours
- Table count: 4
- Pricing: custom per table; owner enters each hourly rate in the owner dashboard before bookings can be accepted.
